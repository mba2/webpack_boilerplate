<section class="breadcrumb">
    <ul class="breadcrumb-list">
        <li class="breadcrumb-path breadcrumb-home">
            <a href="/">
                <img src="img/home-breadcrumb-icon.svg" alt="">
              </a>
        </li>
        <li class="breadcrumb-path"><a>resume</a></li>
        <li class="breadcrumb-path"><a>resume</a></li>
    </ul>
</section>